---
date: "2016-12-01T16:00:00+02:00"
title: "认证"
slug: "authentication"
weight: 10
toc: false
draft: false
menu:
  sidebar:
    parent: "features"
    name: "认证"
    weight: 10
    identifier: "authentication"
---

# 认证

## TBD
