---
date: "2017-01-20T15:00:00+08:00"
title: "需要帮助"
slug: "seek-help"
weight: 10
toc: false
draft: false
menu:
  sidebar:
    parent: "help"
    name: "需要帮助"
    weight: 20
    identifier: "seek-help"
---

## 需要帮助?

如果您在使用或者开发过程中遇到问题，请到以下渠道咨询：

- 到 [GitHub Issue](https://github.com/go-gitea/gitea/issues) 提问(因为项目维护人员来自世界各地，为保证沟通顺畅，请使用英文提问)
- 中文问题到 [Gitea 论坛](https://discourse.gitea.io/c/5-category/5) 提问
- 访问 [Discord Gitea 聊天室 - 英文](https://discord.gg/Gitea)
- 加入 QQ群 328432459 获得进一步的支持
