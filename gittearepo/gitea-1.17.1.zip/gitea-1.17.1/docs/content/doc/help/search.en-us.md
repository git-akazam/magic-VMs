---
date: "2019-11-12T16:00:00+02:00"
title: "Search"
slug: "search"
weight: 4
toc: false
draft: false
menu:
  sidebar:
    parent: "help"
    name: "Search"
    weight: 4
    identifier: "search"
sitemap:
  priority : 0.1
layout: "search"
---


This file exists solely to respond to /search URL with the related `search` layout template.

No content shown here is rendered, all content is based in the template layouts/doc/search.html

Setting a very low sitemap priority will tell search engines this is not important content.
