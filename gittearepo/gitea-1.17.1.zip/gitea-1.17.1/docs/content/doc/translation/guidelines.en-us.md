---
date: "2021-01-22T00:00:00+02:00"
title: "Translation Guidelines"
weight: 10
toc: true
draft: false
menu:
  sidebar:
    parent: "translation"
    name: "Translation Guidelines"
    weight: 70
    identifier: "translation-guidelines"
---

This place is used to provide a common set of rules to make sure the translation is consistent.

* [German](/de-de/übersetzungs-richtlinien/)
