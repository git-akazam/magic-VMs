import 'package:app_flowy/plugins/grid/application/field/type_option/type_option_context.dart';
import 'package:flutter/material.dart';
import 'builder.dart';

class RichTextTypeOptionWidgetBuilder extends TypeOptionWidgetBuilder {
  RichTextTypeOptionWidgetBuilder(RichTextTypeOptionContext typeOptionContext);

  @override
  Widget? build(BuildContext context) => null;
}
