import 'package:app_flowy/plugins/grid/application/field/type_option/type_option_context.dart';
import 'package:flutter/material.dart';
import 'builder.dart';

class CheckboxTypeOptionWidgetBuilder extends TypeOptionWidgetBuilder {
  CheckboxTypeOptionWidgetBuilder(CheckboxTypeOptionContext typeOptionContext);

  @override
  Widget? build(BuildContext context) => null;
}
