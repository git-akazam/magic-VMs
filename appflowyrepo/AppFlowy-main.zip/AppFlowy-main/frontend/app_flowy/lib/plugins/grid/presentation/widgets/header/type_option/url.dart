import 'package:app_flowy/plugins/grid/application/field/type_option/type_option_context.dart';
import 'package:flutter/material.dart';
import 'builder.dart';

class URLTypeOptionWidgetBuilder extends TypeOptionWidgetBuilder {
  URLTypeOptionWidgetBuilder(URLTypeOptionContext typeOptionContext);

  @override
  Widget? build(BuildContext context) => null;
}
