import 'package:flutter/material.dart';

class GridHeaderConstants {
  static Color get backgroundColor => Colors.grey;
}
