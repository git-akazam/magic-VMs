class BoardSizes {
  static double get cardCellVPadding => 6;
}
