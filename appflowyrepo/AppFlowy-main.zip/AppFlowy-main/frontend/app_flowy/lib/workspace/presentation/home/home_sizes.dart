class HomeSizes {
  static double get menuAddButtonHeight => 60;
  static double get topBarHeight => 60;
  static double get editPanelTopBarHeight => 60;
  static double get editPanelWidth => 400;
}

class HomeInsets {
  static double get topBarTitlePadding => 12;
}
