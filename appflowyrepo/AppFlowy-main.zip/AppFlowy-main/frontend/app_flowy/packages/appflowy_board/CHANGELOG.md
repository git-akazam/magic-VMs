# 0.0.8
* Enable drag and drop group  
# 0.0.7
* Rename some classes
* Add documentation
# 0.0.6
* Support scroll to bottom
* Fix some bugs

# 0.0.5
* Optimize insert card animation
* Enable insert card at the end of the group 
* Fix some bugs

# 0.0.4
* Fix some bugs

# 0.0.3
* Support customize UI
* Update example
* Add AppFlowy style widget

# 0.0.2

* Update documentation

# 0.0.1

* Support drag and drop group items from one to another

