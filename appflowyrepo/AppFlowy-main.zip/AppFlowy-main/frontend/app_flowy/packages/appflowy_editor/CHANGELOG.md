## 0.0.5
* Support customize the hotkeys for a shortcut on different platforms.
* Support customize a theme.
* Support localizations.
* Support insert numbered lists.
* Fix some bugs.

## 0.0.4
* Support more shortcut events.
* Fix some bugs.
* Update the documentation.

## 0.0.3
* Support insert image.
* Support insert link.
* Fix some bugs.

## 0.0.2
Minor Updates to Documentation.

## 0.0.1
Initial Version of the library.