<p align="center"><img src="imgs/appflowy_title_and_logo.png" alt="The Open Source Notion Alternative." width="500px" /></p>

# Contributing to AppFlowy

Hello, and welcome! Whether you are trying to report a bug, proposing a feature request, or want to work on the code you should go visit [Contributing to AppFlowy](https://appflowy.gitbook.io/docs/essential-documentation/contribute-to-appflowy/contributing-to-appflowy)

We look forward to hearing from you!
